﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb2
{
    public enum Vehicle
    {
        Car = 1,
        Boat = 2,
        Motorcycle = 3
        
    }
}
