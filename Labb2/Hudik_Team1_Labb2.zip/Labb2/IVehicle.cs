﻿namespace Labb2
{
    interface IVehicle
    {
        int Speed { get; set; }
    }
}